﻿using StupidTemplate.Classes;
using StupidTemplate.Mods;
using static StupidTemplate.Settings;

namespace StupidTemplate.Menu
{
    internal class Buttons
    {
        public static ButtonInfo[][] buttons = new ButtonInfo[][]
        {
            new ButtonInfo[] { // Main Mods
                new ButtonInfo { buttonText = "Menu Settings", method =() => SettingsMods.EnterSettings(), isTogglable = false, toolTip = ""},
                new ButtonInfo { buttonText = "Movement", method =() => Categories.Movement(), isTogglable = false, toolTip = ""},
                new ButtonInfo { buttonText = "Visual", method =() => Categories.Visual(), isTogglable = false, toolTip = ""},
                new ButtonInfo { buttonText = "Rig", method =() => Categories.Rig(), isTogglable = false, toolTip = ""},
                new ButtonInfo { buttonText = "Projectile", method =() => Categories.Projectile(), isTogglable = false, toolTip = ""},
                new ButtonInfo { buttonText = "Safety", method =() => Categories.Safety(), isTogglable = false, toolTip = ""},
                new ButtonInfo { buttonText = "OverPowered", method =() => Categories.Overpowered(), isTogglable = false, toolTip = ""},
            },
             new ButtonInfo[] { // Settings
                new ButtonInfo { buttonText = "Return", method =() => Global.ReturnHome(), isTogglable = false, toolTip = "Returns to the main page of the menu."},
                new ButtonInfo { buttonText = "Right Hand", enableMethod =() => SettingsMods.RightHand(), disableMethod =() => SettingsMods.LeftHand(), toolTip = "Puts the menu on your right hand."},
                new ButtonInfo { buttonText = "Notifications", enableMethod =() => SettingsMods.EnableNotifications(), disableMethod =() => SettingsMods.DisableNotifications(), enabled = !disableNotifications, toolTip = "Toggles the notifications."},
                new ButtonInfo { buttonText = "Disconnect Button", enableMethod =() => SettingsMods.EnableDisconnectButton(), disableMethod =() => SettingsMods.DisableDisconnectButton(), enabled = disconnectButton, toolTip = "Toggles the disconnect button."},
            },

            new ButtonInfo[] { // Movement
                new ButtonInfo { buttonText = "Return", method =() => Global.ReturnHome(), isTogglable = false},
                new ButtonInfo { buttonText = "TogglablePlaceholder", method =() => mods.placeholder(), isTogglable = true},
                new ButtonInfo { buttonText = "Placeholder", method =() => mods.placeholder(), isTogglable = false},
               

            },
             new ButtonInfo[] { // Visual
                new ButtonInfo { buttonText = "Return", method =() => Global.ReturnHome(), isTogglable = false},
                
                
            },
              new ButtonInfo[] { // Rig
                new ButtonInfo { buttonText = "Return", method =() => Global.ReturnHome(), isTogglable = false},
               
                
            },
              new ButtonInfo[] { // Projectile
                new ButtonInfo { buttonText = "Return", method =() => Global.ReturnHome(), isTogglable = false},
               
                
            },
              new ButtonInfo[] { // Saftey
                new ButtonInfo { buttonText = "Return", method =() => Global.ReturnHome(), isTogglable = false},
             
                
            },
              new ButtonInfo[] { // Overpowered
                new ButtonInfo { buttonText = "Return", method =() => Global.ReturnHome(), isTogglable = false},
               
                
            },





        };
    }
}
